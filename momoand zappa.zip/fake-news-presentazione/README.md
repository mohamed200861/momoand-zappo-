# Fake News vs Real News

An interactive, animated slide deck (9 slides, in English with Italian hints) that teaches how to tell a fake news story from a real one. It compares two real cases — the 2002 "teddy bear virus" hoax email and the real 2008 global YouTube outage — and runs both through 8 quick checks.

The deck is interactive. A shared meter at the bottom of the slides fills up as the audience answers: 2 quiz cards, 8 + 8 checks, 4 questions and 4 final checks, **26 steps in total**. When every step is done it shows **26/26 — SAFE TO SHARE**.

Live: https://presentation-zip.netlify.app

## Features

- Editor view with slide thumbnails (toolbar title: "work di zappa e abdel")
- Present mode (`Shift+P`) and Presenter View (`Shift+V`), with an audience window at `/audience`
- PDF export: open `/?print` and print the page
- Grid overlay (`Shift+G`) and dark mode

## Tech

Vite, React 18, TypeScript, Tailwind CSS, shadcn/ui, hosted on Netlify as a static single-page app.

## Run locally

```bash
npm install
npm run dev
```

Then open the address Vite prints.

## Optional: presenter notes storage

Presenter notes can be saved through Supabase if `VITE_SUPABASE_URL` and `VITE_SUPABASE_PUBLISHABLE_KEY` are set. Without them the deck works fine and notes just aren't stored.
