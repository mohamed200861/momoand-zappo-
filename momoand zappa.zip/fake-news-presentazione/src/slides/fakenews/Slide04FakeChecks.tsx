import React from 'react';
import { NewsSlide, Badge, ChecksGrid, delay, Check } from './kit';
import { useReveal } from './reveal';

const checks: Check[] = [
  { title: 'Source', say: 'It is an email from a contact. It is not an official source.', it: 'Non è una fonte ufficiale.' },
  { title: 'Read beyond', say: 'The message creates fear: it says your system will be destroyed.', it: 'Vuole fare paura.' },
  { title: 'Author', say: 'We do not know who wrote it first.', it: 'Autore sconosciuto.' },
  { title: 'Supporting sources', say: 'There is no link and no proof.', it: 'Nessun link e nessuna prova.' },
  { title: 'Date', say: 'It spread in 2002, but the message gives no clear date.', it: 'Manca una data chiara.' },
  { title: 'Joke?', say: 'No. It looks serious, but it is a hoax.', it: 'Non è uno scherzo, è una bufala.' },
  { title: 'Biases', say: 'We fear viruses and we trust our friends.', it: 'Paura e fiducia ci ingannano.' },
  { title: 'Experts', say: 'Microsoft says: do not remove this file. Snopes says it is a hoax.', it: 'Gli esperti la smentiscono.' },
];

export default function Slide04FakeChecks() {
  const reveal = useReveal();
  return (
    <NewsSlide tone="fake" page="04">
      <div className="h-full flex flex-col px-20 pt-16 pb-20">
        <div className="flex items-end justify-between mb-8">
          <div>
            <Badge tone="fake" className="news-rise" style={delay(0)}>Fake news</Badge>
            <h2 className="news-rise text-6xl font-extrabold mt-4" style={delay(100)}>Why we should not trust it</h2>
          </div>
          <p className="news-rise text-2xl text-news-muted max-w-md text-right" style={delay(200)}>{reveal ? '8 simple checks' : '8 simple checks. Click each one.'}</p>
        </div>
        <ChecksGrid checks={checks} tone="fake" />
      </div>
    </NewsSlide>
  );
}
