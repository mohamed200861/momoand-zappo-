import React, { useState } from 'react';
import { cn } from '@/lib/utils';
import { useCharge, useChargeStep } from './charge';
import { useReveal } from './reveal';

type Vars = React.CSSProperties & Record<string, string | number>;

export type Tone = 'real' | 'fake' | 'neutral';

export function delay(ms: number): React.CSSProperties {
  return { animationDelay: `${ms}ms` };
}

/** Deck-wide progress: charges up as answers are given on any slide. */
function ChargeMeter({ dark }: { dark: boolean }) {
  const c = useCharge();
  const pct = Math.round(c.pct * 100);
  const level = pct >= 90 ? 'SAFE TO SHARE' : pct >= 60 ? 'VERIFYING' : pct >= 30 ? 'CHECKING' : 'WARMING UP';
  const bar = pct >= 90 ? 'bg-news-real' : pct >= 60 ? 'bg-slide-accent' : pct >= 30 ? 'bg-news-muted' : 'bg-news-fake';

  return (
    <div className={cn('no-print absolute bottom-6 right-10 z-20 flex items-center gap-4', dark ? 'text-news-paper' : 'text-news-ink')}>
      <span className="text-lg font-bold uppercase tracking-[0.18em] opacity-55">{level}</span>
      <div className={cn('w-[220px] h-3 rounded-full overflow-hidden', dark ? 'bg-news-paper/15' : 'bg-news-ink/10')}>
        <div className={cn('h-full rounded-full transition-all duration-700', bar)} style={{ width: `${pct}%` }} />
      </div>
      <span key={c.done} className="news-meter-pulse text-xl font-extrabold tabular-nums w-16 text-right">{c.done}/{c.total}</span>
    </div>
  );
}

export function NewsSlide({
  children, tone = 'neutral', page, dark = false,
}: { children: React.ReactNode; tone?: Tone; page?: string; dark?: boolean }) {
  return (
    <div
      className={cn(
        'slide-content w-full h-full relative overflow-hidden font-news',
        dark ? 'bg-news-ink text-news-paper' : 'bg-news-paper text-news-ink',
      )}
    >
      {children}
      <ChargeMeter dark={dark} />
      {page && (
        <span className={cn('absolute bottom-8 left-10 text-base font-semibold tabular-nums', dark ? 'text-news-paper/50' : 'text-news-muted')}>
          {page}
        </span>
      )}
      <div className="absolute bottom-0 left-0 right-0 h-2 flex">
        <div className={cn('flex-1 news-bar', tone === 'fake' ? 'bg-news-fake' : tone === 'real' ? 'bg-news-real' : 'bg-news-fake')} />
        <div className={cn('flex-1 news-bar', tone === 'fake' ? 'bg-news-fake' : tone === 'real' ? 'bg-news-real' : 'bg-news-fake')} style={delay(200)} />
      </div>
    </div>
  );
}

export function Badge({ tone, children, className, style }: { tone: Tone; children: React.ReactNode; className?: string; style?: React.CSSProperties }) {
  return (
    <span
      style={style}
      className={cn(
        'inline-block whitespace-nowrap px-6 py-2 text-xl font-bold tracking-[0.12em] uppercase text-news-paper',
        tone === 'fake' ? 'bg-news-fake' : tone === 'real' ? 'bg-news-real' : 'bg-news-ink',
        className,
      )}
    >
      {children}
    </span>
  );
}

function paletteFor(tone: Tone, dark: boolean) {
  if (dark) return ['hsl(var(--news-paper))', 'hsl(var(--news-real))', 'hsl(var(--news-fake))', 'hsl(var(--slide-accent))'];
  if (tone === 'fake') return ['hsl(var(--news-fake))', 'hsl(var(--news-ink))', 'hsl(var(--slide-accent))'];
  if (tone === 'real') return ['hsl(var(--news-real))', 'hsl(var(--news-ink))', 'hsl(var(--slide-accent))'];
  return ['hsl(var(--news-real))', 'hsl(var(--news-fake))', 'hsl(var(--news-ink))', 'hsl(var(--slide-accent))'];
}

const rnd = (a: number, b: number) => a + Math.random() * (b - a);

/** Paper confetti falling from the top. */
export function Confetti({ tone = 'neutral', dark = false, count = 80 }: { tone?: Tone; dark?: boolean; count?: number }) {
  const pieces = React.useMemo(() => {
    const palette = paletteFor(tone, dark);
    return Array.from({ length: count }, (_, i) => ({
      left: rnd(2, 98),
      drift: rnd(-300, 300),
      spin: rnd(360, 1200) * (Math.random() > .5 ? 1 : -1),
      dur: rnd(1.9, 3.4),
      dl: rnd(0, .6),
      w: rnd(9, 18),
      h: rnd(13, 28),
      round: Math.random() > .72,
      color: palette[i % palette.length],
    }));
  }, [tone, dark, count]);

  return (
    <div className="news-confetti" aria-hidden="true">
      {pieces.map((p, i) => (
        <i
          key={i}
          style={{
            left: `${p.left}%`,
            '--w': `${p.w}px`,
            '--h': `${p.h}px`,
            '--c': p.color,
            '--r': p.round ? '50%' : '2px',
            '--d': `${p.dur}s`,
            '--dl': `${p.dl}s`,
            '--drift': `${p.drift}px`,
            '--spin': `${p.spin}deg`,
          } as Vars}
        />
      ))}
    </div>
  );
}

/** Fireworks: radial bursts from several centers. */
export function Fireworks({ tone = 'neutral', dark = false, count = 96 }: { tone?: Tone; dark?: boolean; count?: number }) {
  const pieces = React.useMemo(() => {
    const palette = paletteFor(tone, dark);
    const centers = [[28, 30], [72, 24], [50, 56], [18, 70], [84, 62]];
    return Array.from({ length: count }, (_, i) => {
      const [cx, cy] = centers[i % centers.length];
      const ang = Math.random() * Math.PI * 2;
      const dist = rnd(120, 430);
      return {
        x: cx + rnd(-4, 4),
        y: cy + rnd(-4, 4),
        tx: Math.cos(ang) * dist,
        ty: Math.sin(ang) * dist,
        dur: rnd(1.1, 2),
        dl: rnd(0, .9),
        size: rnd(8, 18),
        color: palette[i % palette.length],
      };
    });
  }, [tone, dark, count]);

  return (
    <div className="news-burst" aria-hidden="true">
      {pieces.map((p, i) => (
        <i
          key={i}
          style={{
            left: `${p.x}%`,
            top: `${p.y}%`,
            '--tx': `${p.tx}px`,
            '--ty': `${p.ty}px`,
            '--d': `${p.dur}s`,
            '--dl': `${p.dl}s`,
            '--w': `${p.size}px`,
            '--c': p.color,
          } as Vars}
        />
      ))}
    </div>
  );
}

/** Expanding rings from the middle of the slide. */
export function Rings({ tone = 'neutral' }: { tone?: Tone }) {
  const c = tone === 'fake' ? 'hsl(var(--news-fake))' : tone === 'real' ? 'hsl(var(--news-real))' : 'hsl(var(--news-ink))';
  return (
    <div className="news-wave" aria-hidden="true">
      {[0, 0.35, 0.7].map((d, i) => (
        <span key={i} style={{ '--c': c, '--dl': `${d}s` } as Vars} />
      ))}
    </div>
  );
}

/** A check mark drawn stroke by stroke. */
export function CheckDraw({ tone = 'real' }: { tone?: Tone }) {
  const c = tone === 'fake' ? 'hsl(var(--news-fake))' : 'hsl(var(--news-real))';
  return (
    <div className="news-draw" aria-hidden="true">
      <svg viewBox="0 0 560 560" fill="none">
        <circle className="d-ring" cx="280" cy="280" r="250" stroke={c} strokeWidth="22" strokeLinecap="round" />
        <path className="d-mark" d="M170 290 L250 372 L400 196" stroke={c} strokeWidth="26" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    </div>
  );
}

/** Twinkling sparkles. */
export function Sparkles({ tone = 'neutral', dark = false, count = 26 }: { tone?: Tone; dark?: boolean; count?: number }) {
  const pieces = React.useMemo(() => {
    const palette = paletteFor(tone, dark);
    const glyphs = ['✦', '✧', '★', '✳', '✦'];
    return Array.from({ length: count }, (_, i) => ({
      x: rnd(4, 96),
      y: rnd(8, 92),
      s: rnd(28, 76),
      dur: rnd(1.2, 2.2),
      dl: rnd(0, 1.1),
      glyph: glyphs[i % glyphs.length],
      color: palette[i % palette.length],
    }));
  }, [tone, dark, count]);

  return (
    <div className="news-sparkles" aria-hidden="true">
      {pieces.map((p, i) => (
        <i
          key={i}
          style={{ left: `${p.x}%`, top: `${p.y}%`, '--c': p.color, '--s': `${p.s}px`, '--d': `${p.dur}s`, '--dl': `${p.dl}s` } as Vars}
        >
          {p.glyph}
        </i>
      ))}
    </div>
  );
}

/** Big verdict stamp slamming down, then fading so the content stays readable. */
export function StampSlam({ tone = 'fake', label = 'FAKE' }: { tone?: Tone; label?: string }) {
  const c = tone === 'fake' ? 'hsl(var(--news-fake))' : 'hsl(var(--news-real))';
  return (
    <>
      <div className="news-flash" style={{ '--c': c } as Vars} aria-hidden="true" />
      <div className="news-slam" aria-hidden="true">
        <span style={{ '--c': c } as Vars}>{label}</span>
      </div>
    </>
  );
}

export type CelebrateKind = 'confetti' | 'fireworks' | 'rings' | 'check' | 'sparkles' | 'stamp';

/** The celebration for a completed step. Each slide picks its own kind. */
export function Celebrate({ kind, tone = 'neutral', dark = false, label }: { kind: CelebrateKind; tone?: Tone; dark?: boolean; label?: string }) {
  const charge = useCharge();
  const boost = Math.round(50 + charge.pct * 60);

  if (kind === 'fireworks') return <Fireworks tone={tone} dark={dark} count={boost + 36} />;
  if (kind === 'rings') return <Rings tone={tone} />;
  if (kind === 'check') return <CheckDraw tone={tone} />;
  if (kind === 'sparkles') return <Sparkles tone={tone} dark={dark} count={Math.round(18 + charge.pct * 16)} />;
  if (kind === 'stamp') return <StampSlam tone={tone} label={label ?? (tone === 'fake' ? 'FAKE' : 'REAL')} />;
  return <Confetti tone={tone} dark={dark} count={boost} />;
}

export interface Check { title: string; say: string; it: string }

/** Eight checks; each card reveals its answer on click (or all at once). */
export function ChecksGrid({ checks, tone }: { checks: Check[]; tone: 'real' | 'fake' }) {
  const reveal = useReveal();
  const [open, setOpen] = useState<boolean[]>(() => checks.map(() => reveal));
  const all = open.every(Boolean);
  const count = open.filter(Boolean).length;
  const toggle = (i: number) => setOpen((o) => o.map((v, j) => (j === i ? !v : v)));
  const color = tone === 'fake' ? 'text-news-fake' : 'text-news-real';
  const bg = tone === 'fake' ? 'bg-news-fake' : 'bg-news-real';
  const soft = tone === 'fake' ? 'bg-news-fake-soft' : 'bg-news-real-soft';

  useChargeStep(tone === 'fake' ? 'checks-fake' : 'checks-real', count, checks.length);

  return (
    <div className="flex flex-col gap-6 flex-1 min-h-0">
      <div className="grid grid-cols-4 grid-rows-2 gap-5 flex-1 min-h-0">
        {checks.map((c, i) => (
          <button
            key={c.title}
            onClick={() => toggle(i)}
            className={cn(
              'news-pop relative overflow-hidden text-left rounded-2xl p-7 flex flex-col border-2 transition-colors duration-300',
              open[i] ? cn(soft, 'border-transparent') : 'bg-white border-news-ink/10 hover:border-news-ink/30',
            )}
            style={delay(150 + i * 90)}
          >
            <div className="flex items-center gap-4 mb-4">
              <span className={cn('relative w-12 h-12 rounded-full flex items-center justify-center text-2xl font-bold text-news-paper shrink-0', open[i] ? bg : 'bg-news-ink')}>
                {open[i] && <span className="news-ring absolute inset-0 rounded-full border-4 border-current" aria-hidden="true" />}
                {open[i] ? (tone === 'fake' ? '✕' : '✓') : i + 1}
              </span>
              <span className="text-2xl font-bold leading-tight">{c.title}</span>
            </div>
            {open[i] ? (
              <div className="news-rise flex flex-col gap-3">
                <p className="text-2xl leading-snug">{c.say}</p>
                <p className={cn('text-xl italic', color)}>{c.it}</p>
              </div>
            ) : (
              <p className="text-xl text-news-muted mt-auto">Click to check →</p>
            )}
          </button>
        ))}
      </div>
      <div className="flex items-center gap-6">
        <div className={cn('flex-1', all && 'news-glow')}>
          <div className="h-4 rounded-full bg-news-ink/10 overflow-hidden">
            <div className={cn('h-full rounded-full transition-all duration-500', bg)} style={{ width: `${(count / checks.length) * 100}%` }} />
          </div>
        </div>
        <span className={cn('text-xl font-semibold tabular-nums w-28 transition-colors duration-300', all && color)}>{count} / {checks.length}</span>
        <span className={cn('text-xl font-semibold whitespace-nowrap', all ? cn(color, 'news-pop') : 'text-news-muted')}>
          {all ? 'All checks done ✓' : 'Click each card'}
        </span>
        <button
          onClick={() => setOpen(checks.map(() => !all))}
          className="no-print whitespace-nowrap px-6 py-3 rounded-full bg-news-ink text-news-paper text-xl font-semibold"
        >
          {all ? 'Hide all' : 'Show all'}
        </button>
        {all && (
          <span className={cn('news-tada border-4 rounded-lg px-5 py-1 text-3xl font-extrabold tracking-widest', tone === 'fake' ? 'border-news-fake text-news-fake' : 'border-news-real text-news-real')}>
            {tone === 'fake' ? 'FAKE ✓' : 'REAL ✓'}
          </span>
        )}
      </div>

      {all && <Celebrate kind={tone === 'fake' ? 'stamp' : 'check'} tone={tone} label={tone === 'fake' ? 'FAKE' : 'REAL'} />}
      {all && (
        <div
          className={cn(
            'news-banner pointer-events-none absolute inset-x-6 top-6 bottom-16 rounded-3xl border-[10px] z-20',
            tone === 'fake' ? 'border-news-fake/60' : 'border-news-real/60',
          )}
        />
      )}
    </div>
  );
}
