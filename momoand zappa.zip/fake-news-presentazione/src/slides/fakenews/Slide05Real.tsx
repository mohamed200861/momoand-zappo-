import React from 'react';
import globe from '@/assets/youtube_globe.png.asset.json';
import { NewsSlide, Badge, delay } from './kit';

const dots = [
  { x: 15, y: 20 }, { x: 80, y: 15 }, { x: 88, y: 60 }, { x: 10, y: 70 }, { x: 50, y: 5 }, { x: 70, y: 88 }, { x: 25, y: 92 },
];

export default function Slide05Real() {
  return (
    <NewsSlide tone="real" page="05">
      <div className="absolute inset-y-0 left-0 w-[58%] bg-news-real-soft" />
      <div className="relative h-full grid grid-cols-[58%_42%]">
        <div className="flex flex-col justify-center px-24">
          <Badge tone="real" className="news-rise w-fit" style={delay(0)}>Real news</Badge>
          <h2 className="news-rise text-7xl font-extrabold leading-[1.05] mt-6 mb-12" style={delay(150)}>Pakistan blocks YouTube… around the world</h2>
          <p className="news-rise text-3xl leading-snug mb-6" style={delay(300)}>In February 2008, Pakistan wanted to block YouTube <b>only in its own country.</b></p>
          <p className="news-rise text-3xl leading-snug mb-6" style={delay(450)}>A Pakistani Internet company made a technical mistake. Many people in the world could not open YouTube for <b>about two hours.</b></p>
          <p className="news-rise text-3xl leading-snug" style={delay(600)}>This news is <b className="text-news-real">REAL</b>.</p>
          <p className="news-rise text-2xl italic text-news-muted mt-8" style={delay(750)}>Per un errore tecnico, il blocco si è esteso ad altri paesi per circa due ore.</p>
        </div>
        <div className="relative flex items-center justify-center">
          <div className="relative w-[640px] h-[640px]">
            {dots.map((d, i) => (
              <span key={i} className="absolute" style={{ left: `${d.x}%`, top: `${d.y}%` }}>
                <span className="news-pulse absolute -inset-4 rounded-full bg-news-fake/40" style={delay(i * 350)} />
                <span className="news-pop relative block w-5 h-5 rounded-full bg-news-fake" style={delay(900 + i * 150)} />
              </span>
            ))}
            <img src={globe.url} alt="Globe with the YouTube logo" className="news-float absolute inset-10 w-[560px]" />
          </div>
          <p className="text-xl text-news-muted absolute bottom-20">Incident record · February 2008</p>
        </div>
      </div>
    </NewsSlide>
  );
}
