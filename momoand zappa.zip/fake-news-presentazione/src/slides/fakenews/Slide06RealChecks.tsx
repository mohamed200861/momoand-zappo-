import React from 'react';
import { NewsSlide, Badge, ChecksGrid, delay, Check } from './kit';
import { useReveal } from './reveal';

const checks: Check[] = [
  { title: 'Source', say: 'The Register is a technology news website with contact information.', it: 'È un sito di notizie tecnologiche con i contatti.' },
  { title: 'Read beyond', say: 'Pakistan wanted a local block, but the problem became global.', it: 'Il blocco doveva essere solo locale.' },
  { title: 'Author', say: 'The article has an author: John Oates.', it: "L'articolo è firmato." },
  { title: 'Supporting sources', say: 'It links to the BBC. Dark Reading and RIPE NCC report it too.', it: 'Altre fonti la confermano.' },
  { title: 'Date', say: 'February 25th, 2008. It is real, but old.', it: 'Vera ma vecchia.' },
  { title: 'Joke?', say: 'No. It is serious technology news.', it: 'È una notizia seria.' },
  { title: 'Biases', say: 'We think one company cannot block a big website, so it looks fake.', it: 'Sembra impossibile, ma è successo.' },
  { title: 'Experts', say: 'RIPE NCC, an organization of Internet experts, studied the event.', it: "Esperti di internet l'hanno analizzata." },
];

export default function Slide06RealChecks() {
  const reveal = useReveal();
  return (
    <NewsSlide tone="real" page="06">
      <div className="h-full flex flex-col px-20 pt-16 pb-20">
        <div className="flex items-end justify-between mb-8">
          <div>
            <Badge tone="real" className="news-rise" style={delay(0)}>Real news</Badge>
            <h2 className="news-rise text-6xl font-extrabold mt-4" style={delay(100)}>Why we can trust it</h2>
          </div>
          <p className="news-rise text-2xl text-news-muted max-w-md text-right" style={delay(200)}>{reveal ? 'The same 8 checks' : 'The same 8 checks. Click each one.'}</p>
        </div>
        <ChecksGrid checks={checks} tone="real" />
      </div>
    </NewsSlide>
  );
}
