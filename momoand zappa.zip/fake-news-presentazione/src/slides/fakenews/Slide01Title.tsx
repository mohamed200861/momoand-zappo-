import React from 'react';
import { NewsSlide, Badge, delay } from './kit';

export default function Slide01Title() {
  return (
    <NewsSlide dark>
      <div className="absolute -left-40 top-1/2 -translate-y-1/2 w-[900px] h-[900px] rounded-full bg-news-fake/20 blur-3xl" />
      <div className="absolute -right-40 top-1/2 -translate-y-1/2 w-[900px] h-[900px] rounded-full bg-news-real/20 blur-3xl" />
      <div className="relative h-full flex flex-col justify-center px-32">
        <p className="news-rise text-2xl uppercase tracking-[0.3em] text-news-paper/60 mb-10" style={delay(100)}>Tech Talk · Computers & the Internet</p>
        <h1 className="text-[150px] font-extrabold leading-[0.95] tracking-tight">
          <span className="news-rise block text-news-fake" style={delay(250)}>Fake news</span>
          <span className="news-rise block text-news-paper/40 text-[80px] my-4" style={delay(450)}>vs</span>
          <span className="news-rise block text-news-real" style={delay(650)}>Real news</span>
        </h1>
        <p className="news-rise text-4xl text-news-paper/80 mt-12 max-w-4xl" style={delay(900)}>
          Two stories about computers. One is fake and one is real. Can you tell which?
        </p>
      </div>
      <div className="absolute right-32 top-1/2 -translate-y-1/2 flex flex-col gap-10 items-end">
        <Badge tone="fake" className="news-stamp text-4xl px-10 py-4" style={delay(1200)}>Fake?</Badge>
        <Badge tone="real" className="news-stamp text-4xl px-10 py-4" style={delay(1500)}>Real?</Badge>
      </div>
    </NewsSlide>
  );
}
