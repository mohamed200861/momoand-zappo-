import Slide01Title from './Slide01Title';
import Slide02Quiz from './Slide02Quiz';
import Slide03Fake from './Slide03Fake';
import Slide04FakeChecks from './Slide04FakeChecks';
import Slide05Real from './Slide05Real';
import Slide06RealChecks from './Slide06RealChecks';
import Slide07Compare from './Slide07Compare';
import Slide09Questions from './Slide09Questions';
import Slide10End from './Slide10End';

export const fakeNewsSlides = [
  { component: Slide01Title, name: 'Fake vs Real', template: 'title' },
  { component: Slide02Quiz, name: 'Quiz', template: 'interactive' },
  { component: Slide03Fake, name: 'Teddy bear virus', template: 'split' },
  { component: Slide04FakeChecks, name: 'Fake checks', template: 'grid' },
  { component: Slide05Real, name: 'YouTube blocked', template: 'split' },
  { component: Slide06RealChecks, name: 'Real checks', template: 'grid' },
  { component: Slide07Compare, name: 'Side by side', template: 'comparison' },
  { component: Slide09Questions, name: 'Questions', template: 'interactive' },
  { component: Slide10End, name: 'Check before you share', template: 'cta' },
];
