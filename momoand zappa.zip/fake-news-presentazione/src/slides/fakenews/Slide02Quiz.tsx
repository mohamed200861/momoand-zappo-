import React, { useState } from 'react';
import { cn } from '@/lib/utils';
import { NewsSlide, Celebrate, delay } from './kit';
import { useChargeStep } from './charge';
import { useReveal } from './reveal';

const stories = [
  { emoji: '🧸', title: 'A teddy bear file destroys your computer in 14 days', year: '2002', real: false },
  { emoji: '🌍', title: 'One country blocks YouTube for the whole world', year: '2008', real: true },
];

export default function Slide02Quiz() {
  const reveal = useReveal();
  const [shown, setShown] = useState<boolean[]>(() => (reveal ? [true, true] : [false, false]));
  const both = shown.every(Boolean);
  useChargeStep('quiz', shown.filter(Boolean).length, stories.length);

  return (
    <NewsSlide page="02">
      {both && <Celebrate kind="confetti" />}
      <div className="h-full flex flex-col px-24 py-20">
        <p className="news-rise text-2xl uppercase tracking-[0.25em] text-news-muted" style={delay(0)}>Quick quiz</p>
        <h2 className="news-rise text-7xl font-extrabold mt-4 mb-4" style={delay(100)}>Fake or real? You decide.</h2>
        {both ? (
          <span className="news-tada w-fit border-4 border-news-ink rounded-xl px-6 py-1 text-3xl font-extrabold tracking-[0.14em]">
            BOTH CHECKED ✓
          </span>
        ) : (
          <p className="news-rise text-3xl text-news-muted mb-14" style={delay(200)}>Click a card to see the answer.</p>
        )}
        <div className="grid grid-cols-2 gap-12 flex-1 mt-10">
          {stories.map((s, i) => (
            <button
              key={s.title}
              onClick={() => setShown((v) => v.map((x, j) => (j === i ? !x : x)))}
              className="news-flip news-pop text-left"
              style={delay(350 + i * 200)}
            >
              <div className={cn('news-flip-inner relative w-full h-full', shown[i] && 'flipped')}>
                <div className="news-face absolute inset-0 rounded-3xl bg-white border-2 border-news-ink/10 p-14 flex flex-col">
                  <span className="text-[120px] leading-none news-float inline-block w-fit">{s.emoji}</span>
                  <p className="text-5xl font-bold leading-tight mt-10">“{s.title}”</p>
                  <p className="text-2xl text-news-muted mt-auto">{s.year} · Click to reveal</p>
                </div>
                <div className={cn('news-face news-back absolute inset-0 rounded-3xl p-14 flex flex-col items-center justify-center text-news-paper', s.real ? 'bg-news-real' : 'bg-news-fake')}>
                  {shown[i] && (
                    <span className="news-pop text-[180px] font-extrabold tracking-tight leading-none">{s.real ? 'REAL' : 'FAKE'}</span>
                  )}
                  {shown[i] && (
                    <p className="news-pop text-3xl mt-8 text-news-paper/90" style={delay(220)}>
                      {s.real ? 'It really happened!' : 'It is a hoax!'}
                    </p>
                  )}
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </NewsSlide>
  );
}
