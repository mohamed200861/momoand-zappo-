import React, { useState } from 'react';
import { cn } from '@/lib/utils';
import { NewsSlide, Celebrate, delay } from './kit';
import { useChargeStep } from './charge';
import { useReveal } from './reveal';

const qa = [
  ['Why did people believe the email?', 'The file was really in the computer and a friend sent the message.'],
  ['What happened if you deleted the file?', 'Usually no big problem. It was only for some Java programmers.'],
  ['Why did YouTube stop in other countries?', 'Other networks received and copied the wrong information.'],
  ['How long was the problem?', 'About two hours. The Register says more than one hour.'],
];

export default function Slide09Questions() {
  const reveal = useReveal();
  const [open, setOpen] = useState<number | null>(null);
  const [seen, setSeen] = useState<Set<number>>(() =>
    reveal ? new Set(qa.map((_, i) => i)) : new Set(),
  );
  const click = (i: number) => {
    setOpen(open === i ? null : i);
    setSeen((s) => (s.has(i) ? s : new Set(s).add(i)));
  };
  const all = seen.size === qa.length;
  useChargeStep('qa', seen.size, qa.length);

  return (
    <NewsSlide page="08">
      {all && <Celebrate kind="rings" />}
      <div className="h-full flex flex-col px-24 py-16">
        <div className="flex items-end justify-between gap-8 mb-3 min-h-[72px]">
          <h2 className="news-rise text-6xl font-extrabold" style={delay(0)}>Questions?</h2>
          {all && (
            <span className="news-tada border-4 border-news-real text-news-real rounded-xl px-6 py-1 text-2xl font-extrabold tracking-[0.14em] whitespace-nowrap">
              ALL ANSWERED ✓
            </span>
          )}
        </div>
        <p className={cn('news-rise text-3xl mb-10', all ? 'text-news-real font-semibold' : 'text-news-muted')} style={delay(100)}>
          {all ? 'Every question opened — nice work!' : 'Click a question to show the answer.'}
        </p>
        <div className="flex flex-col gap-5">
          {qa.map(([q, a], i) => (
            <button key={q} onClick={() => click(i)}
              className={cn('news-rise text-left rounded-2xl px-10 py-7 border-2 transition-colors duration-300', open === i ? 'bg-news-ink text-news-paper border-news-ink' : 'bg-white border-news-ink/10')}
              style={delay(200 + i * 120)}>
              <div className="flex items-center justify-between gap-6">
                <span className="text-4xl font-bold">{q}</span>
                <span className={cn('text-5xl transition-transform duration-300', (open === i || reveal) && 'rotate-45')}>+</span>
              </div>
              {(open === i || reveal) && <p className={cn('news-rise text-3xl mt-4', open === i ? 'text-news-paper/90' : 'text-news-ink/80')}>{a}</p>}
            </button>
          ))}
        </div>
      </div>
    </NewsSlide>
  );
}
