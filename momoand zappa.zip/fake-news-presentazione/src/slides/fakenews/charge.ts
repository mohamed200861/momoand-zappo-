import { useEffect, useSyncExternalStore } from 'react';

/**
 * Deck-wide "charge": every answered step across every slide adds to one meter.
 * Monotonic on purpose — the meter only ever charges up, so the audience sees
 * progress build as the talk moves forward.
 */
type Entry = { done: number; total: number };
type Snapshot = { done: number; total: number; pct: number };

const entries = new Map<string, Entry>();
const listeners = new Set<() => void>();
let cached: Snapshot | null = null;

function snapshot(): Snapshot {
  if (!cached) {
    let done = 0;
    let total = 0;
    entries.forEach((e) => {
      done += e.done;
      total += e.total;
    });
    cached = { done, total, pct: total ? done / total : 0 };
  }
  return cached;
}

function emit() {
  cached = null;
  listeners.forEach((l) => l());
}

/** Report how many steps of one slide are answered. Safe to call from every copy of a slide. */
export function useChargeStep(key: string, done: number, total: number) {
  useEffect(() => {
    const prev = entries.get(key);
    const next = { done: Math.max(prev?.done ?? 0, done), total };
    if (!prev || prev.done !== next.done || prev.total !== total) {
      entries.set(key, next);
      emit();
    }
  }, [key, done, total]);
}

export function useCharge(): Snapshot {
  return useSyncExternalStore(
    (cb) => {
      listeners.add(cb);
      return () => {
        listeners.delete(cb);
      };
    },
    snapshot,
    snapshot,
  );
}

export function resetCharge() {
  entries.clear();
  emit();
}
