import React from 'react';
import bear from '@/assets/teddy_bear_monitor.png.asset.json';
import { NewsSlide, Badge, delay } from './kit';

export default function Slide03Fake() {
  return (
    <NewsSlide tone="fake" page="03">
      <div className="absolute inset-y-0 left-0 w-[58%] bg-news-fake-soft" />
      <div className="relative h-full grid grid-cols-[58%_42%]">
        <div className="flex flex-col justify-center px-24">
          <Badge tone="fake" className="news-rise w-fit" style={delay(0)}>Fake news</Badge>
          <h2 className="news-rise text-7xl font-extrabold leading-[1.05] mt-6 mb-12" style={delay(150)}>The teddy bear virus</h2>
          <p className="news-rise text-3xl leading-snug mb-6" style={delay(300)}>In 2002, many people got an email: <b>there is a virus in your computer.</b></p>
          <p className="news-rise text-3xl leading-snug mb-6" style={delay(450)}>The file is <code className="bg-white px-2 rounded">jdbgmgr.exe</code>, with a small bear icon. “Delete it and tell all your contacts.”</p>
          <p className="news-rise text-3xl leading-snug" style={delay(600)}>This news is <b className="text-news-fake">FAKE</b>. It was a normal Microsoft file.</p>
          <p className="news-rise text-2xl italic text-news-muted mt-8" style={delay(750)}>Era un normale file di Microsoft. Sembrava vero perché il file c’era davvero.</p>
        </div>
        <div className="relative flex flex-col items-center justify-center">
          <img src={bear.url} alt="Old computer monitor showing a teddy bear" className="news-float w-[600px]" />
          <div className="news-pop absolute top-[150px] right-[60px] bg-white rounded-xl shadow-xl border-2 border-news-fake px-6 py-4 max-w-[340px]" style={delay(900)}>
            <p className="text-xl font-bold text-news-fake">⚠ WARNING: VIRUS!</p>
            <p className="text-lg text-news-muted">Delete it now and forward to everyone!!</p>
          </div>
          <span className="news-stamp absolute bottom-[200px] left-[70px] border-[6px] border-news-fake text-news-fake rounded-xl px-8 py-2 text-6xl font-extrabold tracking-widest" style={delay(1400)}>HOAX</span>
          <p className="text-xl text-news-muted absolute bottom-20">Email hoax · jdbgmgr.exe · 2002</p>
        </div>
      </div>
    </NewsSlide>
  );
}
