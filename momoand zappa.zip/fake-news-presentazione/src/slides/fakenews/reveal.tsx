import React, { createContext, useContext } from 'react';

/**
 * Print mode. A PDF handout cannot be clicked, so the print route turns this on
 * and every interactive slide renders in its revealed state (answers shown,
 * checks opened, cards flipped) instead of its "click me" state.
 */
const RevealContext = createContext(false);

export const RevealProvider = RevealContext.Provider;

export function useReveal(): boolean {
  return useContext(RevealContext);
}
