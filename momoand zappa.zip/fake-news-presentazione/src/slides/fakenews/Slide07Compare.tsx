import React from 'react';
import { NewsSlide, delay } from './kit';

const rows = [
  ['Source', 'Email from a friend', 'Tech news website'],
  ['Author', 'Unknown', 'John Oates'],
  ['Proof', 'No link, no proof', 'BBC, Dark Reading, RIPE NCC'],
  ['Date', 'No clear date', '25 February 2008'],
  ['Experts', 'Microsoft & Snopes: hoax', 'RIPE NCC studied it'],
];

export default function Slide07Compare() {
  return (
    <NewsSlide page="07">
      <div className="h-full flex flex-col px-24 py-16">
        <h2 className="news-rise text-6xl font-extrabold mb-10" style={delay(0)}>Side by side</h2>
        <div className="grid grid-cols-[260px_1fr_1fr] gap-x-8 text-3xl">
          <div />
          <div className="news-pop bg-news-fake text-news-paper rounded-t-2xl px-8 py-5 font-extrabold text-4xl" style={delay(150)}>🧸 Teddy bear virus</div>
          <div className="news-pop bg-news-real text-news-paper rounded-t-2xl px-8 py-5 font-extrabold text-4xl" style={delay(250)}>🌍 YouTube blocked</div>
          {rows.map(([k, f, r], i) => (
            <React.Fragment key={k}>
              <div className="news-rise py-6 font-bold border-b-2 border-news-ink/10" style={delay(400 + i * 150)}>{k}</div>
              <div className="news-rise py-6 px-8 bg-news-fake-soft border-b-2 border-news-paper flex gap-4" style={delay(450 + i * 150)}><span className="text-news-fake font-bold">✕</span>{f}</div>
              <div className="news-rise py-6 px-8 bg-news-real-soft border-b-2 border-news-paper flex gap-4" style={delay(500 + i * 150)}><span className="text-news-real font-bold">✓</span>{r}</div>
            </React.Fragment>
          ))}
        </div>
        <p className="news-rise text-3xl text-news-muted mt-auto" style={delay(1300)}>Looks true ≠ is true. Looks strange ≠ is fake.</p>
      </div>
    </NewsSlide>
  );
}
