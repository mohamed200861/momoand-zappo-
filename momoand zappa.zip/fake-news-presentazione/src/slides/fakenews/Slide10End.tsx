import React, { useState } from 'react';
import { cn } from '@/lib/utils';
import { NewsSlide, Celebrate, delay } from './kit';
import { useChargeStep } from './charge';
import { useReveal } from './reveal';

const checks = [
  { en: 'Who wrote it?', it: "Chi l'ha scritto?" },
  { en: 'Is there a link?', it: "C'è un link?" },
  { en: 'When was it published?', it: 'Quando è stato pubblicato?' },
  { en: 'Do others report it?', it: 'Altri ne parlano?' },
];

export default function Slide10End() {
  const reveal = useReveal();
  const [open, setOpen] = useState<boolean[]>(() => checks.map(() => reveal));
  const all = open.every(Boolean);
  const count = open.filter(Boolean).length;
  const toggle = (i: number) => setOpen((o) => o.map((v, j) => (j === i ? !v : v)));
  useChargeStep('final', count, checks.length);

  return (
    <NewsSlide dark>
      {all && <Celebrate kind="fireworks" dark />}
      <div className="h-full flex items-center gap-16 px-24 py-16">
        {/* ---------- Left: message ---------- */}
        <div className="flex-1 min-w-0 flex flex-col justify-center">
          <p className="news-rise text-4xl text-news-paper/70 leading-snug max-w-4xl" style={delay(0)}>
            A news story can <span className="text-news-real font-bold">look true</span> and be <span className="text-news-fake font-bold">fake</span>.
            It can <span className="text-news-fake font-bold">look strange</span> and be <span className="text-news-real font-bold">real</span>.
          </p>
          <h2 className="news-rise text-[140px] font-extrabold leading-none tracking-tight mt-8 whitespace-nowrap" style={delay(400)}>Check before</h2>
          <h2 className="news-rise text-[140px] font-extrabold leading-none tracking-tight whitespace-nowrap" style={delay(600)}>you <span className="text-news-real">share.</span></h2>
          {all && <div className="news-bar h-3 bg-news-real rounded-full w-[620px] mt-5" />}
          <p className="news-rise text-5xl font-bold mt-10" style={delay(900)}>Thank you! {all ? '🎉' : '👋'}</p>
          <p className="news-rise text-2xl italic text-news-paper/50 mt-3" style={delay(1000)}>Controlla prima di condividere.</p>
        </div>

        {/* ---------- Right: interactive checklist ---------- */}
        <div
          className={cn(
            'news-pop w-[560px] shrink-0 rounded-3xl border-2 p-8 flex flex-col gap-5 transition-colors duration-500',
            all ? 'border-news-real bg-news-real/[0.08] news-glow' : 'border-news-paper/15 bg-white/[0.04]',
          )}
          style={delay(1100)}
        >
          <div className="flex items-center justify-between">
            <span className="text-xl font-bold tracking-[0.14em] uppercase text-news-paper/60">Before you share</span>
            <span className={cn('text-xl font-bold tabular-nums transition-colors duration-300', all ? 'text-news-real' : 'text-news-paper/60')}>{count} / {checks.length}</span>
          </div>

          <div className="flex flex-col gap-3">
            {checks.map((c, i) => (
              <button
                key={c.en}
                onClick={() => toggle(i)}
                className={
                  'news-rise text-left rounded-2xl px-6 py-4 flex items-center gap-4 border-2 transition-colors duration-300 ' +
                  (open[i] ? 'bg-news-real/20 border-news-real' : 'bg-white/[0.03] border-news-paper/15 hover:border-news-paper/40')
                }
                style={delay(1250 + i * 110)}
              >
                <span className={'relative w-11 h-11 rounded-full flex items-center justify-center text-2xl font-bold shrink-0 ' + (open[i] ? 'bg-news-real text-news-paper' : 'bg-news-paper/10 text-news-paper')}>
                  {open[i] && <span className="news-ring absolute inset-0 rounded-full border-4 border-current" aria-hidden="true" />}
                  {open[i] ? '✓' : i + 1}
                </span>
                <span className="flex flex-col">
                  <span className="text-2xl font-bold leading-tight">{c.en}</span>
                  <span className="text-lg italic text-news-paper/55">{c.it}</span>
                </span>
              </button>
            ))}
          </div>

          <div className="flex items-center gap-4">
            <div className={cn('flex-1', all && 'news-glow')}>
              <div className="h-4 rounded-full bg-news-paper/10 overflow-hidden">
                <div className="h-full rounded-full bg-news-real transition-all duration-500" style={{ width: `${(count / checks.length) * 100}%` }} />
              </div>
            </div>
            <span className={cn('text-lg font-semibold whitespace-nowrap transition-colors duration-300', all ? 'text-news-real' : 'text-news-paper/60')}>
              {all ? 'you can share it' : 'click each question'}
            </span>
          </div>

          {all && (
            <div className="news-tada self-center border-4 border-news-real rounded-xl px-6 py-2 text-3xl font-extrabold tracking-[0.18em] text-news-real">
              SAFE TO SHARE ✓
            </div>
          )}
        </div>
      </div>
    </NewsSlide>
  );
}
