import React from 'react';
import { fakeNewsSlides } from '@/slides/fakenews';
import { RevealProvider } from '@/slides/fakenews/reveal';

/**
 * Print / PDF export view: every slide stacked at its true 1920x1080 size,
 * one slide per printed page. Reached with `?print`; the browser's
 * "Save as PDF" then produces the handout.
 *
 * RevealProvider shows every interactive state, because paper cannot be clicked.
 */
export function PrintDeck() {
  return (
    <RevealProvider value={true}>
      <div className="print-deck">
        {fakeNewsSlides.map(({ component: Slide, name }) => (
          <div className="print-page" key={name} data-slide={name}>
            <Slide />
          </div>
        ))}
      </div>
    </RevealProvider>
  );
}
