# AGENTS.md

## What this is
A static Vite + React + TypeScript slide deck ("Fake News vs Real News"), first built in Lovable and now hosted on Netlify. No server code runs on Netlify.

## Key directories
- `src/slides/fakenews/` — **the actual deck.** `index.ts` lists the 9 slides in order. `kit.tsx` holds shared slide building blocks (NewsSlide, ChecksGrid, Celebrate, the charge meter). `charge.ts` is the deck-wide progress store. `reveal.tsx` turns on "show everything" mode for print/thumbnails.
- `src/slides/demo/`, `src/slides/showcase/` — leftover Lovable template slides. Not used by the deck; you can ignore them.
- `src/components/slides/` — editor, presentation mode, presenter view, print view.
- `src/components/layout/Toolbar.tsx` — top bar (title "work di zappa e abdel").
- `src/pages/Index.tsx` — main editor page; `?print` switches to the export view. `src/pages/AudienceWindow.tsx` is the `/audience` route.
- `supabase/` — Lovable's Supabase config/migrations. Netlify doesn't use it.

## Conventions and things to know
- **The meter total must stay 26.** Every interactive slide reports `useChargeStep(key, done, total)`: quiz 2, fake checks 8, real checks 8, questions 4, final checks 4. If you add or remove interactive items, the total changes.
- Colors come from `news-*` Tailwind tokens (`news-ink`, `news-paper`, `news-real`, `news-fake`, `news-muted`) defined in `tailwind.config.ts` / `src/index.css`. When a card switches to a dark background (`bg-news-ink`), its text has to switch to `text-news-paper`. Otherwise it disappears.
- Slides are designed on a fixed 1920×1080 canvas and scaled with `ScaledSlide`.
- Supabase is only loaded lazily for presenter notes, and only if `VITE_SUPABASE_URL` is set. Don't import the Supabase client at the top level, or the site crashes when the variable isn't set.
- `netlify.toml` installs dependencies (including dev ones like `vite`) and then runs `npm run build`, publishes `dist`, and has an SPA fallback redirect so `/audience` works.
